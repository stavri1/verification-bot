const { ApplicationCommandType, PermissionsBitField, ApplicationCommandOptionType, ButtonStyle, ButtonBuilder, ActionRowBuilder, EmbedBuilder, StringSelectMenuBuilder } = require('discord.js');
const { QuickDB } = require("quick.db");
const db = new QuickDB({ filePath: "./database/verify.sqlite" });

module.exports = {
    name: 'setup-verification',
    description: 'Set up the verification system for this server.',
    type: ApplicationCommandType.ChatInput,
  userPerms: [PermissionsBitField.Flags.ManageGuild],
    options: [
        {
            name: 'role',
            description: 'The role you want to add to verified users.',
            type: ApplicationCommandOptionType.Role,
            required: true
        },
        {
            name: 'channel',
            description: 'The channel where the verification message will be sent.',
            type: ApplicationCommandOptionType.Channel,
            required: false,
            channelTypes: ['GUILD_TEXT'], 
            autocomplete: true
        }
    ],
    run: async (client, interaction) => {
        const role = interaction.options.get('role').role;
        const channel = interaction.options.getChannel('channel', false);

        await db.set(`verification.${interaction.guild.id}`, { Role: role.id, Channel: channel?.id, Verified: [] });

        const selectMenu = new StringSelectMenuBuilder()
        .setCustomId('verification_level')
        .setPlaceholder('Select verification level')
        .addOptions(
            {
                label: 'Low',
                value: 'low',
                emoji:'🔴',
                description: 'Click the button to verify'
            },
            {
                label: 'Medium',
                value: 'medium',
                emoji:'🟡',
                description: 'Verification with buttons Captcha'
            },
            {
                label: 'High',
                value: 'high',
                emoji:'🟢',
                description: 'Verification with Modal Captcha'
            }
        );
    
    
        const verify = new EmbedBuilder()
            .setColor('#20be30')
            .setThumbnail(interaction.guild.iconURL())
            .setTimestamp()
            .setTitle('• Verification Select verification level')
            .setAuthor({ name: `✅ Verification Process` })
            .setFooter({ text: `Powered by C4 Clan Community`, iconURL: interaction.guild.iconURL() })


            const msg = await interaction.reply({ content: `Your **verification system** has been set up!`, embeds: [verify], components: [new ActionRowBuilder().addComponents(selectMenu)], ephemeral: true });

        const filter = (i) => i.customId === 'verification_level';
        const collector = msg?.createMessageComponentCollector({ filter, time: 60000 });

        collector?.on('collect', async (i) => {
            if (i.customId === 'verification_level') {
                const level = i.values[0];
                if (level === 'low') {
                    const verify = new EmbedBuilder()
                    .setColor('#20be30')
                        .setThumbnail(interaction.guild.iconURL())
                        .setTimestamp()
                        .setTitle('• Verification Message')
                        .setDescription('Please click the button \`Verify\` below to verify.')
                        .setAuthor({ name: `✅ Verification Process` })
                        .setFooter({ text: `✅ Verification Prompt` });

                    const buttons = new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                                .setCustomId(`verify${level}`)
                                .setLabel('✅ Verify')
                                .setStyle(ButtonStyle.Success)
                        );

                    await channel?.send({ embeds: [verify], components: [buttons] });
                    await i.update({ content: `Your **verification system ${level}** has been set up!`, components: [], ephemeral: true  });
                } else if (level === 'medium') {
                    const verify = new EmbedBuilder()
                    .setColor('#20be30')
                        .setThumbnail(interaction.guild.iconURL())
                        .setTimestamp()
                        .setTitle('• Verification')
                        .setDescription('Please click the button \`Verify\` below to verify.')
                        .setAuthor({ name: `✅ Verification Process` })
                        .setFooter({ text: `✅ Verification Prompt` });

                    const buttons = new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                                .setCustomId(`verify${level}`)
                                .setLabel('✅ Verify')
                                .setStyle(ButtonStyle.Success)
                        );

                    await channel?.send({ embeds: [verify], components: [buttons] });
                    await i.update({ content: `Your **verification system ${level}** has been set up!`, components: [], ephemeral: true  });
                } else if (level === 'high') {
                    const verify = new EmbedBuilder()
                    .setColor('#20be30')
                        .setThumbnail(interaction.guild.iconURL())
                        .setTimestamp()
                        .setTitle('• Verification Message')
                        .setDescription('Please click the button \`Verify\` below to verify.')
                        .setAuthor({ name: `✅ Verification Process` })
                        .setFooter({ text: `✅ Verification Prompt` });

                    const buttons = new ActionRowBuilder()
                        .addComponents(
                            new ButtonBuilder()
                                .setCustomId(`verify${level}`)
                                .setLabel('✅ Verify')
                                .setStyle(ButtonStyle.Success)
                        );

                    await channel?.send({ embeds: [verify], components: [buttons] });
                    await i.update({ content: `Your **verification system ${level}** has been set up!`, components: [], ephemeral: true  });
                }
            }
        });
    }
};


///////////////////////////////////////////////////////////////////
///////// dev by tn hazem youtube
///////// server discord https://discord.gg/c4-clan-community-917454141087965244
//////// Development c4 clan community
/////////////////////////////////////////////////////////////////