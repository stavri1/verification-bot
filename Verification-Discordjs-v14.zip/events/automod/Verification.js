
const { CaptchaGenerator } = require('captcha-canvas');
const { EmbedBuilder, ModalBuilder, AttachmentBuilder,TextInputBuilder, TextInputStyle, ButtonBuilder, ActionRowBuilder, ButtonStyle } = require(`discord.js`);
const client = require("../../index.js");
const { QuickDB } = require("quick.db");
const db = new QuickDB({ filePath: "./database/verify.sqlite" });
const  low = 'low';
const  medium = 'medium';
const  high = 'high';

///////////////////////////////////////////////////////////////////
////////// low verification
///////// dev by tn hazem youtube
///////// server discord https://discord.gg/c4-clan-community-917454141087965244
//////// Development c4 clan community
/////////////////////////////////////////////////////////////////
client.on('interactionCreate', async interaction => {
  if (interaction.guild === null) return;
  
    const verificationData = await db.get(`verification.${interaction.guild.id}`);

    if (interaction.customId === `verify${low}`) {
      const memberRole = await interaction.guild.roles.fetch(verificationData.Role);
            
          await interaction.member.roles.add(memberRole);
       
          await interaction.reply({ content: 'You have been verified successfully!', ephemeral: true });
          }
        });

///////////////////////////////////////////////////////////////////
////////// medium verification
///////// dev by tn hazem youtube
///////// server discord https://discord.gg/c4-clan-community-917454141087965244
//////// Development c4 clan community
/////////////////////////////////////////////////////////////////
client.on('interactionCreate', async interaction => {
if (interaction.guild === null) return;
  const verifydata = await db.get(`verification.${interaction.guild.id}`);
  const verifyusersdata = await db.get(`verifyusers.${interaction.guild.id}.${interaction.user.id}`);

  if (interaction.customId === `verify${medium}`) {

          let letter = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'A', 'b', 'B', 'c', 'C', 'd', 'D', 'e', 'E', 'f', 'F', 'g', 'G', 'h', 'H', 'i', 'I', 'j', 'J', 'f', 'F', 'l', 'L', 'm', 'M', 'n', 'N', 'o', 'O', 'p', 'P', 'q', 'Q', 'r', 'R', 's', 'S', 't', 'T', 'u', 'U', 'v', 'V', 'w', 'W', 'x', 'X', 'y', 'Y', 'z', 'Z'];
          let result = Math.floor(Math.random() * letter.length);
          let result2 = Math.floor(Math.random() * letter.length);
          let result3 = Math.floor(Math.random() * letter.length);
          let result4 = Math.floor(Math.random() * letter.length);
          let result5 = Math.floor(Math.random() * letter.length);

          const cap = letter[result] + letter[result2] + letter[result3] + letter[result4] + letter[result5];
          console.log(cap);
          function shuffle(array) {
            for (let i = array.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [array[i], array[j]] = [array[j], array[i]]; 
            }
            return array;
        }

        let selectedButtons = Array.from(cap); 
        let uniqueButtons = [...new Set(selectedButtons)]; 
        uniqueButtons = shuffle(uniqueButtons); 
    
          const captcha = new CaptchaGenerator()
              .setDimension(150, 450)
              .setCaptcha({ text: `${cap}`, size: 60, color: "green" })
              .setDecoy({ opacity: 0.5 })
              .setTrace({ color: "green" });

          const buffer = captcha.generateSync();

          const verifyattachment = new AttachmentBuilder(buffer, { name: `captcha.png` });

          const verifyembed = new EmbedBuilder()
              .setColor('#20be30')
              .setAuthor({ name: `🔐 Secure Verification | ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() })
              .setFooter({ text: `✅ Verification Captcha` })
              .setTimestamp()
              .setImage('attachment://captcha.png')
              .setTitle('> Verification Step: Captcha')
              .addFields(
                { name: 'enter code', value: '\`\`\`.\`\`\`' },
            );
              let buttonRow1 = new ActionRowBuilder();
let buttonRow2 = new ActionRowBuilder();
              uniqueButtons.forEach((char, index) => {
                if (index < 5) {
                    buttonRow1.addComponents(
                        new ButtonBuilder()
                            .setLabel(char)
                            .setCustomId(`char_${char}`)
                            .setStyle(ButtonStyle.Secondary)
                    );
                } else {
                    buttonRow2.addComponents(
                        new ButtonBuilder()
                            .setLabel(char)
                            .setCustomId(`char_${char}`)
                            .setStyle(ButtonStyle.Secondary)
                    );
                }
            });
        
              // Adding confirm and cancel buttons
              buttonRow2.addComponents(
                new ButtonBuilder()
                  .setLabel('Confirm')
                  .setCustomId('confirm')
                  .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                  .setLabel('Cancel')
                  .setCustomId('cancel')
                  .setStyle(ButtonStyle.Danger)
              );


              await db.set(`verifyusers.${interaction.guild.id}.${interaction.user.id}`, cap);


          await interaction.reply({ embeds: [verifyembed], components: [buttonRow1, buttonRow2 ], ephemeral: true, files: [verifyattachment] });

          await db.set(`verifyuserss.${interaction.guild.id}.${interaction.user.id}`, { userInput: '' });
        }

      else if (interaction.customId && interaction.customId.startsWith('char_')) { 
        let char = interaction.customId.split('_')[1];
          let currentData = await db.get(`verifyuserss.${interaction.guild.id}.${interaction.user.id}`);
          let updatedInput = `${currentData.userInput}${char}`;
    
          await db.set(`verifyuserss.${interaction.guild.id}.${interaction.user.id}.userInput`, updatedInput);
          if (interaction.message && interaction.message.embeds.length > 0) {
            const storedCaptcha = await db.get(`verifyusers.${interaction.guild.id}.${interaction.user.id}`);

            const captcha = new CaptchaGenerator()
            .setDimension(150, 450)
            .setCaptcha({ text: `${storedCaptcha}`, size: 60, color: "green" })
            .setDecoy({ opacity: 0.5 })
            .setTrace({ color: "green" });

        const buffer = captcha.generateSync();

        const verifyattachment = new AttachmentBuilder(buffer, { name: `captcha.png` });
                     const verifyembed = new EmbedBuilder()
              .setColor('#20be30')
              .setAuthor({ name: `🔐 Secure Verification | ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() })

              .setFooter({ text: `✅ Verification Captcha` })
              .setTimestamp()
              .setImage('attachment://captcha.png')
              .setTitle('> Verification Step: Captcha')
              .addFields(
                { name: `• Verify`, value: '> Please use the button bellow to \n> submit your captcha!' },
                { name: 'enter code', value: `\`\`\`${updatedInput}\`\`\`` },
            );
            await interaction.update({ embeds: [verifyembed], files: [verifyattachment]  });
        } else {
            console.error('No embeds found in the message to update.');
            await interaction.reply({ content: 'No embeds to update.', ephemeral: true });
        }
        
        }
      
        else if (interaction.customId === 'confirm') {
          let userData = await db.get(`verifyuserss.${interaction.guild.id}.${interaction.user.id}`);
          const correctCaptcha = await db.get(`verifyusers.${interaction.guild.id}.${interaction.user.id}`);
        
          await interaction.update({ content: '<a:loading:1237706233994149898> loading Verifying...',files: [] , embeds: [],components: [] });

          await new Promise(resolve => setTimeout(resolve, 3000));
        
          if (userData.userInput === correctCaptcha) {
            const verificationData = await db.get(`verification.${interaction.guild.id}`);
            const memberRole = await interaction.guild.roles.fetch(verificationData.Role);
        
            await interaction.member.roles.add(memberRole);
        
            await interaction.editReply({ content: 'Verification successful!',files: [] , embeds: [],components: [] });
          } else {
            await interaction.editReply({ content: 'Verification failed. Incorrect CAPTCHA.',files: [], embeds: [],components: [] });
          }
        }
        else if (interaction.customId === 'cancel') {
  
          await db.delete(`verifyuserss.${interaction.guild.id}.${interaction.user.id}`);
          
          await interaction.update({
            content: 'Verification process has been cancelled.',
            embeds: [],
            components: [],
            files:[]
          });
        }
      });
///////////////////////////////////////////////////////////////////
////////// high verification
///////// dev by tn hazem youtube
///////// server discord https://discord.gg/c4-clan-community-917454141087965244
//////// Development c4 clan community
////////////////////////////////////////////////////////////////
      client.on('interactionCreate', async interaction => {
        if (interaction.guild === null) return;
        
          const verifydata = await db.get(`verification.${interaction.guild.id}`);
          const verifyusersdata = await db.get(`verifyusers.${interaction.guild.id}.${interaction.user.id}`);
          if (interaction.customId === `verify${high}`) {
                  let letter = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'A', 'b', 'B', 'c', 'C', 'd', 'D', 'e', 'E', 'f', 'F', 'g', 'G', 'h', 'H', 'i', 'I', 'j', 'J', 'f', 'F', 'l', 'L', 'm', 'M', 'n', 'N', 'o', 'O', 'p', 'P', 'q', 'Q', 'r', 'R', 's', 'S', 't', 'T', 'u', 'U', 'v', 'V', 'w', 'W', 'x', 'X', 'y', 'Y', 'z', 'Z'];
                  let result = Math.floor(Math.random() * letter.length);
                  let result2 = Math.floor(Math.random() * letter.length);
                  let result3 = Math.floor(Math.random() * letter.length);
                  let result4 = Math.floor(Math.random() * letter.length);
                  let result5 = Math.floor(Math.random() * letter.length);
                  const cap = letter[result] + letter[result2] + letter[result3] + letter[result4] + letter[result5];
                  console.log(cap);
                  
                  const captcha = new CaptchaGenerator()
                      .setDimension(150, 450)
                      .setCaptcha({ text: `${cap}`, size: 60, color: "green" })
                      .setDecoy({ opacity: 0.5 })
                      .setTrace({ color: "green" });
        
                  const buffer = captcha.generateSync();
        
                  const verifyattachment = new AttachmentBuilder(buffer, { name: `captcha.png` });
        
                  const verifyembed = new EmbedBuilder()
                      .setColor('#20be30')
                      .setAuthor({ name: `🔐 Secure Verification | ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() })
                      .setTimestamp()
                      .setImage('attachment://captcha.png')
                      .setTitle('> Verification Step: Captcha');
                  const verifybutton = new ActionRowBuilder()
                      .addComponents(
                          new ButtonBuilder()
                              .setLabel('Enter Captcha')
                              .setStyle(ButtonStyle.Success)
                              .setCustomId('captchaenter')
                      );
               
        
                      await db.set(`verifyusers.${interaction.guild.id}.${interaction.user.id}`, cap);

                  await interaction.reply({ embeds: [verifyembed], components: [verifybutton ], ephemeral: true, files: [verifyattachment] });
        
                  await db.set(`verifyuserss.${interaction.guild.id}.${interaction.user.id}`, { userInput: '' });
                }
              });
          
client.on('interactionCreate', async interaction => {
if (!interaction.isCommand() && interaction.isButton() && interaction.customId === 'captchaenter') {
    const captchaData = await db.get(`verifyusers.${interaction.guild.id}.${interaction.user.id}`);
    
    if (captchaData) {
        const modal = new ModalBuilder()
            .setCustomId('verificationModal')
            .setTitle('Captcha Verification');
        
        const captchaInput = new TextInputBuilder()
            .setCustomId('captchaInput')
            .setLabel('Enter the Captcha Code')
            .setStyle(TextInputStyle.Short)
            .setRequired(true);
        
        const firstActionRow = new ActionRowBuilder().addComponents(captchaInput);
        modal.addComponents(firstActionRow);
    
        await interaction.showModal(modal);

    }
}
else if (interaction.isModalSubmit() && interaction.customId === 'verificationModal') {
    const userResponse = interaction.fields.getTextInputValue('captchaInput');
    const storedCaptcha = await db.get(`verifyusers.${interaction.guild.id}.${interaction.user.id}`);
    
    if (userResponse === storedCaptcha) {
        const verificationData = await db.get(`verification.${interaction.guild.id}`);
        
        if (verificationData && verificationData.Verified && verificationData.Verified.includes(interaction.user.id)) {
            await interaction.reply({ content: 'You have already been verified!', ephemeral: true });
        } else {
            const memberRole = await interaction.guild.roles.fetch(verificationData.Role);
            
            if (memberRole) {
                await interaction.member.roles.add(memberRole);
             
                await interaction.reply({ content: 'You have been verified successfully!', ephemeral: true });
            }
        }
    } else {
        await interaction.reply({ content: 'Invalid Captcha Code. Please try again.', ephemeral: true });
    }
}
});